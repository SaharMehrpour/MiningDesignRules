<a name="v0.1.0"></a>
## v0.1.0 (2013-12-28)


#### Features

* **publisher:** initial publisher use commit ([a144e2f8](https://github.com/angular-ui/ui-codemirror/commit/a144e2f8b3134df9e4a9ce313778b0086ea82af9))

