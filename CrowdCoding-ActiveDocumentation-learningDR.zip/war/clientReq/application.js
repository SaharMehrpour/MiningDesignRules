// create the AngularJS app, load modules and start

var clienRequestApp = angular.module('clientRequest',["firebase","mgcrea.ngStrap"]);

clienRequestApp.run();



