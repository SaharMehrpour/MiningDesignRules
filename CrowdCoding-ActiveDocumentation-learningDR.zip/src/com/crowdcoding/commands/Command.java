package com.crowdcoding.commands;

public abstract class Command {
	public abstract void execute(String projectId);
}
