package com.crowdcoding.dto;

import java.util.ArrayList;
import java.util.List;


public class ChallengeDTO extends DTO
{

	public String challengeText;

	// Default constructor (required by Jackson JSON library)
	public ChallengeDTO()
	{
	}

}
