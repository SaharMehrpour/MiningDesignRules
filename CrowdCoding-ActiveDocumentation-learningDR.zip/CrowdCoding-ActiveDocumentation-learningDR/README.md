CrowdCode
This is a repository hosting the CrowdCode codebase for working with ActiveDocumentation.

Branch [ActiveDocumentation-Study-VL/HCC2019](https://github.com/devuxd/CrowdCoding-ActiveDocumentation/tree/ActiveDocumentation-Study-VL/HCC2019) 
is used in _"Active Documentation: Helping Developers Follow Design Decisions"_. 
See [here](https://github.com/devuxd/CrowdCoding-ActiveDocumentation/blob/ActiveDocumentation-Study-VL/HCC2019/README.md)
for more details.

Branch [designDoc](https://github.com/devuxd/CrowdCoding-ActiveDocumentation/tree/designDoc) 
contains an additional artifact [*designDoc*](https://github.com/devuxd/CrowdCoding-ActiveDocumentation/commit/1f0849fce2d51137c4bb5a96b7ec71f24bd3d41e).

Branch [learningDR](https://github.com/devuxd/CrowdCoding-ActiveDocumentation/tree/learningDR) 
contains [spmf.jar](https://github.com/devuxd/CrowdCoding-ActiveDocumentation/blob/learningDR/spmf.jar)
for learning design rules.